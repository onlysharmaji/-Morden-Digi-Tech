# Morden Digi Tech — Website

Fast & Reliable Computer, Laptop & OS Solutions — Aligarh, UP

## Files Structure (GitHub Root mein yahi hona chahiye)

```
/ (ROOT — koi subfolder nahi)
├── index.html
├── style.css  
├── script.js
├── assets/
│   └── (apni images yahan daalo)
├── .github/
│   └── workflows/
│       └── static.yml   ← auto-deploy
└── README.md
```

## Google Form Link Replace Karna

`index.html` mein dhundho:
```
YOUR_GOOGLE_FORM_LINK
```
Aur apna actual Google Form ID se replace karo.

## Contact
- Phone: 7599913980
- Email: mordendigitechmail@gmail.com
- Instagram: @mordendigitech
- Location: Aligarh, UP – 202122
